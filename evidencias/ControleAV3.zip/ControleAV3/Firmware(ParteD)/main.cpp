#include <Arduino.h>
#include <Baratinha.h>
#include <math.h>

Baratinha bra; // Instancia unica do robo Baratinha

namespace { // Escopo anonimo para constantes locais e variaveis de estado
  
  // --- CONFIGURAÇÕES DE CONTROLE ---
  const float Ts = 0.01f; // Periodo de controle (10ms)
  
  // Ganhos do PID (Calculados na Parte B)
  // Nota: Estes ganhos foram projetados para uma planta normalizada.
  // Como o erro agora é em mm (escala 0-100+), o Kp de ~0.01 gera uma saída próxima de 1.0
  const float Kp = 0.0106f;  
  const float Ki = 0.0001f;   
  const float Kd = 0.3279f;   

  // Filtro do termo Derivativo (Suavização)
  // 0.9999 é um filtro muito forte (alta inércia no D), útil para sensores muito ruidosos.
  const float alpha_filter = 0.9999f; 

  // --- PARÂMETROS FÍSICOS (EM MILÍMETROS) ---
  const float setpoint_mm = 100.0f;       // Alvo: 10 cm = 100 mm
  const float dist_seguranca_mm = 30.0f;  // Parada de emergência: 3 cm = 30 mm
  
  // Limites do PWM (Hardware)
  const float pwm_max_float = 255.0f;
  const float pwm_min_float = -255.0f;

  // --- VARIÁVEIS DE ESTADO (MEMÓRIA) ---
  float erro_anterior = 0.0f;
  float termo_i = 0.0f;           // Acumulador da integral
  float termo_d_filtrado = 0.0f;  // Memória do filtro derivativo
}

void setup() {
  bra.recoveryMode(); // Verifica botão para modo de recuperação
  bra.setupAll();     // Configuração do hardware

  bra.setControlInterval(Ts); 
  
  // Configura telemetria para debug
  bra.enableTelemetry(true);
  bra.setTelemetryDivider(1); // Envia todas as amostras (100Hz)

  bra.println("[Main] Controlador PID Iniciado (Unidade: mm).");
  bra.awaitStart(); // Aguarda botão para iniciar
}

void loop() {
  bra.updateStartStop(); 
  
  // Se não estiver rodando, reseta as memórias do controlador
  if (!bra.isRunning()){
    bra.stop();
    termo_i = 0.0f;
    erro_anterior = 0.0f;
    termo_d_filtrado = 0.0f;
    return; 
  }
  
  // Verifica se é o momento exato da amostragem (Ts)
  if (!bra.controlTickDue()) return; 

  // ============================================================
  // 1. LEITURA DO SENSOR (EM MM)
  // ============================================================
  // O sensor retorna nativamente em mm. Não convertemos para cm.
  float dist_mm = bra.readDistance();

  // ============================================================
  // 2. SEGURANÇA (EMERGÊNCIA)
  // ============================================================
  // Se estiver muito perto (< 30mm) e a leitura for válida (> 0.1mm)
  if (dist_mm < dist_seguranca_mm && dist_mm > 0.1f) {
    bra.stop();
    termo_i = 0.0f; // Reseta integrador
    return;
  }

  // ============================================================
  // 3. CÁLCULO DO ERRO
  // ============================================================
  // Erro = Valor Atual - Setpoint
  // Se estiver em 150mm (longe), erro = 50. Precisa andar p/ frente (+PWM).
  float erro = dist_mm - setpoint_mm;

  // ============================================================
  // 4. TERMO PROPORCIONAL (P)
  // ============================================================
  float P = Kp * erro;

  // ============================================================
  // 5. TERMO DERIVATIVO COM FILTRO (D)
  // ============================================================
  // Derivada "crua": (erro atual - erro anterior) / tempo
  float derivada_raw = (erro - erro_anterior) / Ts;
  
  // Filtro Exponencial: Suaviza picos de ruído do sensor ToF
  float D = (alpha_filter * termo_d_filtrado) + ((1.0f - alpha_filter) * Kd * derivada_raw);
  
  // Atualiza memória do filtro e do erro
  termo_d_filtrado = D;
  erro_anterior = erro;

  // ============================================================
  // 6. CÁLCULO PRELIMINAR E ANTI-WINDUP (I)
  // ============================================================
  
  // Calcula o novo incremento integral proposto
  float novo_termo_i = termo_i + (Ki * erro * Ts);
  
  // Calcula a saída "crua" NORMALIZADA (idealmente entre -1.0 e 1.0)
  float u_normalized = P + novo_termo_i + D;
  
  // --- ESCALONAMENTO DE PRECISÃO (FLOAT) ---
  // Multiplicamos por 255 AGORA, mantendo em float para não perder casas decimais.
  // Isso atende ao requisito de não usar casting prematuro.
  float u_scaled = u_normalized * 255.0f;

  // Verificação de Saturação (Anti-Windup Clamping)
  // Verificamos se o sinal escalonado excede os limites físicos (255)
  bool saturado = false;

  if (u_scaled > pwm_max_float) {
    u_scaled = pwm_max_float; // Trava a saída em 255.0
    saturado = true;
    // Se o erro for positivo, ele quer aumentar ainda mais a saída -> BLOQUEIA INTEGRAL
    // Se o erro for negativo, ele quer sair da saturação -> PERMITE INTEGRAL
    if (erro < 0) termo_i = novo_termo_i; 
    
  } else if (u_scaled < pwm_min_float) {
    u_scaled = pwm_min_float; // Trava a saída em -255.0
    saturado = true;
    // Se o erro for negativo, quer diminuir mais -> BLOQUEIA
    // Se o erro for positivo, quer sair -> PERMITE
    if (erro > 0) termo_i = novo_termo_i;
    
  } else {
    // Região linear (não saturado): Atualiza integral normalmente
    termo_i = novo_termo_i;
  }

  // ============================================================
  // 7. ATUAÇÃO FINAL
  // ============================================================
  
  // Somente agora fazemos o cast para int, exigido pela função de hardware.
  // Como 'u_scaled' já foi travado entre -255.0 e 255.0, o cast é seguro.
  int pwm_out = (int)u_scaled;
  
  // Aciona os motores (true liga os LEDs de direção)
  bra.move1D(pwm_out, true); 

  // ============================================================
  // 8. TELEMETRIA
  // ============================================================
  // Envia dados para o Serial Plotter.
  // Debugamos o u_normalized para ver o comportamento matemático (-1 a 1)
  // E o pwm_out para ver o comportamento físico.
  // bra.emitTelemetry(setpoint_mm, dist_mm, erro, u_normalized, (float)pwm_out, P, termo_i, D);
}